Assignment 1
- To start, open data.php file
- Use data.csv to upload the data
- Classes folder contains all classes used in this assignment
- Data folder contains uploaded data file, and all other files that are created
- Go to courses.php to see all courses
- Go to students.php to see all students